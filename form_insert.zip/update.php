<?php
include "cadastro_cliente.php";
$id = $_POST['id_cadastro'];
$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$sexo = $_POST['sexo'];


echo "id: $id";

mysqli_query($link,"update cliente 
set nome ='$nome', email ='$email', senha='$senha', sexo='$sexo' WHERE id_cadastro = '$id'");

header("location: select.php");
?>