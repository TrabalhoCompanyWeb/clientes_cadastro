<html>
    <head>
        <!--Import Google Icon Font-->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!--Import materialize.css-->
        <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />
        <link rel="stylesheet" href="css/style.css">
        <!--Let browser know website is optimized for mobile-->
        <meta lang="pt-br">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Cadastrando Clientes</title>
    </head>
<body>
<nav>
    <div class="navbar-fixed">
        <nav class="black light-black darken-3">
            <div class="nav-wrapper" style="text-align: center">
                <a href="index.html" class="brand-logo center">Millennial Fashion</a>
            </div>
        </nav>
    </div>
</nav>

    <h2>Cadastro  de Novos Clientes</h2>
    <br>
    <br>
    
    <!-- Formulario de cadastro-->
      
               <div class="row">
                     <div class="col s6">
                         <div class="card-panel z-depth-5">
                             <form action="cadastro.php" method="POST">
                                <input type="hidden" name="id_cadastro" value="<?= $id ?>" >
                                  <h4>Crie conta na Millennial Fashion 
                                    
                                    <h6>
                                    Use o mesmo login e senha para acessar a Millennial Fashion. Sua compra ficou muito mais fácil e rápida.
                                    </h6>
                                 </h4>
                                 <br>
                                 <br>

                                 <div class="input-field">
                                  <input name="nome" type="text" class="nome">
                                  <label for="nome"><i class="material-icons left">account_circle</i>Nome</label>
                                </div>
                                    <div class="input-field">
                                      <input name="email" placeholder="Digite seu e-mail" type="email" class="validate">
                                      <label for="email"><i class="material-icons left">email</i>E-mail</label>
                                      <span class="helper-text" data-error="wrong" data-success="right"></span>
                                    </div>
                                       <div class="input-field">
                                           <input name="senha" placeholder="****.." type="password" class="validate">
                                           <label for="password"><i class="material-icons left">lock_outline</i>Senha</label>
                                       </div>
                                       <div class="input-field">
                                         <select name="sexo">
                                            <option value="" disabled selected>Sexo</option>
                                            <option value="feminino">Feminino</option>
                                            <option value="masculino">Masculino</option>
                                         </select>
                                      </div>
                                       <div class="login button center-align">
                                           <button type="submit" name="enviar" class="waves-effect waves-light btn btn-large">Cadastrar</button>
                                        </div>
                                  </form>
                             </div>
                         </div>
                    </div>
               
       
   
    <!--Import jQuery before materialize.js-->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="js/materialize.min.js"></script>
        <script>
            $(document).ready(function() {
            $('.slider').slider();
            $(".button-collapse").sideNav();
            $(".dropdown-button").dropdown();
            $('select').material_select();
                var options = [
            {selector: '.class', offset: 200, callback: customCallbackFunc },
            {selector: '.other-class', offset: 200, callback: function() {
            customCallbackFunc();
            } },
            ];
            Materialize.scrollFire(options);
            });
        </script>
</body>
</html>