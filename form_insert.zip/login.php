  <?php
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "usuario";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
//começa a sessão usada pra logar
session_start();

if(isset($_POST['logar'])){
	
	$email = $_POST['email'];
	$senha = $_POST['senha'];
	
	//checa se o usuario OU email é igual o que ta na db
	$sql = "SELECT * FROM users WHERE email = '$email' OR nome ='$nome'";
	$result = mysqli_query($conn, $sql);
	$resultCheck = mysqli_num_rows($result);
	//checa se encontra o usuario>
	if($resultCheck < 1){
		header("Location: index.html?login=error");
		exit();
	} else {
		if($row = mysqli_fetch_assoc($result)){
			//de-hash a senha
			//check se é igual a da db

				//loga o usuario
				//passa variaveis pra sessão
				$_SESSION['nome'] = $row['nome'];
				$_SESSION['email'] = $row['email'];
                $_SESSION['senha'] = $row['senha'];
				$_SESSION['sexo'] = $row['sexo'];
				header("Location: index.html?login=success");
				exit();
		}
	}
	
} else {
	header("Location: index.html?login=error");
	exit();
}

