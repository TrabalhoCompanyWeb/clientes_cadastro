<html>
    <head>
        <title>Clientes</title>
        <!--Import Google Icon Font-->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!--Import materialize.css-->
        <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />
        <link rel="stylesheet" href="css/style.css">
        <!--Let browser know website is optimized for mobile-->
        <meta lang="pt-br">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>
<body>
<nav>
    <div class="navbar-fixed">
        <nav class="black light-black darken-3">
            <div class="nav-wrapper" style="text-align: center">
                <a href="index.html" class="brand-logo center">Millennial Fashion</a>
            </div>
        </nav>
    </div>
</nav>
<h2>Tela de Dados</h2>
<hr>

<?php
include "cadastro_cliente.php";

$consulta = mysqli_query($link,"select * from cliente");
while($vetor = mysqli_fetch_array($consulta)){
    $id = $vetor['id_cadastro'];
    $nome = $vetor['nome'];
    $email = $vetor['email'];
    $senha = $vetor['senha'];
    $sexo = $vetor['sexo'];
    
    
    echo "<a href='form_update.php?id_cadastro=$id' >Alterar</a><br>";
    echo "<a href='form_delete.php?id_cadastro=$id' >Deletar</a><br>";

    echo "Id: $id<br>";
    echo "Nome: $nome<br>";
    echo "E-mail: $email<br>";
    echo "Senha: $senha<br>";
    echo "Sexo: $sexo<hr>";

}
?>

    <!--Import jQuery before materialize.js-->
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="js/materialize.min.js"></script>
        <script>
            $(document).ready(function() {
            $('.slider').slider();
            $(".button-collapse").sideNav();
            $(".dropdown-button").dropdown();
            $('select').material_select();
                var options = [
        {selector: '.class', offset: 200, callback: customCallbackFunc },
        {selector: '.other-class', offset: 200, callback: function() {
        customCallbackFunc();
        } },
    ];
    Materialize.scrollFire(options);
            });
    </script>

</body>
</html>