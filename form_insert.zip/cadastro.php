<?php
include "cadastro_cliente.php";

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$sexo = $_POST['sexo'];

mysqli_query($link,"insert into cliente(nome,email,senha,sexo)values('$nome','$email','$senha','$sexo')");
header("location: select.php");
?>