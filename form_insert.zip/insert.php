<?php
include "cadastro_fornecedor.php";

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$sexo = $_POST['sexo']


mysqli_query($link,"insert into clientes(nome,email,senha,sexo)values('$nome','$email','$senha','$sexo')");

//header("location: select.php");
?>