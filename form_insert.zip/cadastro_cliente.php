<?php 
$host = "localhost";
$user = "root";
$pass = "";
$db = "crud";

$link = mysqli_connect($host,$user,$pass,$db);
?>